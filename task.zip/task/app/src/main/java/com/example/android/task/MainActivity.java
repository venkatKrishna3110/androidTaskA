package com.example.android.task;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    public void login(View view){
        EditText username = (EditText) findViewById( R.id.userName);
        EditText password = (EditText)findViewById(R.id.pswd);
        CheckBox rememberMe = (CheckBox) findViewById(R.id.remember_me_checkbox);
        boolean hasRememberMe = rememberMe.isChecked();

        Intent intent = new Intent(MainActivity.this,Activity2.class);
        intent.putExtra("username", username.getText().toString());
        startActivity(intent);


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}
