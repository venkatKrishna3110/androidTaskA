package com.example.android.task;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;

/**
 * Created on 12/15/2017.
 */

public class Activity2 extends MainActivity {


    Calendar myCalendar = Calendar.getInstance();

    EditText edittext= (EditText) findViewById(R.id.date);
    DatePickerDialog.OnDateSetListener dateBox = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            // TODO Auto-generated method stub
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            }

    };
    TimePicker simpleTimePicker=(TimePicker)findViewById(R.id.simpleTimePicker);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen2);

    }

}
